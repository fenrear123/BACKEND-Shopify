// app/models/associations.js
const Product = require('./productsModel');
const Category = require('./categoriesModel');
const Customer = require('./customersModel');
const Order = require('./ordersModel');

// Define associations here
Product.belongsTo(Category);
Category.hasMany(Product);

Order.belongsTo(Customer);
Customer.hasMany(Order);

module.exports = { Product, Category, Customer, Order };
