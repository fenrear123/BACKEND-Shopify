const { check, validationResult } = require('express-validator');
const Product = require('../models/productsModel');

// Add a new product
const addProduct = async (req, res) => {
  // Validate request body
  await check('name', 'Name is required').notEmpty().run(req);
  await check('description', 'Description is required').notEmpty().run(req);
  await check('price', 'Price is required and should be a number').isFloat({ gt: 0 }).run(req);
  await check('stock', 'Stock is required and should be an integer').isInt({ gt: 0 }).run(req);

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, description, price, stock } = req.body;
  try {
    const newProduct = await Product.create({ name, description, price, stock });
    res.status(201).json(newProduct);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get all products
const getProducts = async (req, res) => {
  try {
    const products = await Product.findAll();
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  addProduct,
  getProducts,
};
