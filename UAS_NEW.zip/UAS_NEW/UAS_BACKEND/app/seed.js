const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('uas_db', 'root', '', {
    host: 'db', // Nama service database di docker-compose
    dialect: 'mysql'
});

// Definisikan model sesuai dengan skema Anda
const User = sequelize.define('User', {
    username: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    }
});

const Product = sequelize.define('Product', {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false
    }
});

const Order = sequelize.define('Order', {
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    productId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    quantity: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});

const Category = sequelize.define('Category', {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    }
});

const Review = sequelize.define('Review', {
    productId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    rating: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    comment: {
        type: DataTypes.TEXT,
        allowNull: false
    }
});

// Fungsi untuk mengisi data sampel
const seedDatabase = async () => {
    await sequelize.sync({ force: true });

    // Seed User
    const users = [];
    for (let i = 0; i < 20; i++) {
        users.push({
            username: `user${i}`,
            password: 'password',
            email: `user${i}@example.com`
        });
    }
    await User.bulkCreate(users);

    // Seed Product
    const products = [];
    for (let i = 0; i < 50; i++) {
        products.push({
            name: `Product${i}`,
            price: (i + 1) * 10,
            description: `Description for Product${i}`
        });
    }
    await Product.bulkCreate(products);

    // Seed Order
    const orders = [];
    for (let i = 0; i < 50; i++) {
        orders.push({
            userId: (i % 20) + 1,
            productId: (i % 50) + 1,
            quantity: (i % 5) + 1
        });
    }
    await Order.bulkCreate(orders);

    // Seed Category
    const categories = [];
    for (let i = 0; i < 50; i++) {
        categories.push({
            name: `Category${i}`
        });
    }
    await Category.bulkCreate(categories);

    // Seed Review
    const reviews = [];
    for (let i = 0; i < 500; i++) {
        reviews.push({
            productId: (i % 50) + 1,
            userId: (i % 20) + 1,
            rating: (i % 5) + 1,
            comment: `Comment for Product${i % 50} by User${i % 20}`
        });
    }
    await Review.bulkCreate(reviews);

    console.log("Data seeding completed.");
};

seedDatabase().catch(err => console.log(err));
